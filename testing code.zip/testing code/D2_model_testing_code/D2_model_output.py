import cv2 
import matplotlib.pyplot as plt 
import numpy as np


import tensorflow as tf
import tensorflow.keras
from tensorflow.keras.layers import Dense, Conv2D, Flatten, MaxPool2D, Dropout, Input
import keras
from keras import backend as k
import math as m

def FrameCapture(path_source,path_destination): 
    # Path to video file 
    vidObj = cv2.VideoCapture(path_source) 
    count=0

    success = 1
    while success: 

        success, image = vidObj.read() 

        path=path_destination+str(count)+".jpg"
        if success:
          cv2.imwrite(path, image) 
          shape=image.shape
          count += 1
    print('done and total frames=',count,'image shape',shape,'input',path_source)
    return count,shape
def frame_to_video(size,no_of_frames,magnified_frames,name,format):
  out = cv2.VideoWriter(name,cv2.VideoWriter_fourcc(*format), 30, size)#XVID, MJPG, X264, WMV1, works
  for i in range(no_of_frames):
      filename=magnified_frames+str(i)+'.jpg'
      img = cv2.imread(filename)
      img = cv2.resize(img, size)
      out.write(img)
  import matplotlib.pyplot as plt 
  plt.imshow(img/255)
  return print('done')


def magnification(no_of_frames,file_path,gap,m_f,output_path,size_image,weights_path):

    filters_=8
    image_height=size_image[0]
    image_width=size_image[0]
    activaion_function='elu'
    
    vgg16=tf.keras.applications.VGG16(# weights='imagenet',
        include_top=True, input_tensor=None, input_shape=None,weights='imagenet',
        pooling=None, classes=1000, classifier_activation='softmax')
    vgg16.trainable=False
    fullModel = tf.keras.models.Model(inputs = vgg16.input, outputs = vgg16.layers[9].output)
    fullModel.compile(loss='mse', optimizer='adam')
    fullModel.summary()
    def perceptual_loss(y_true, y_pred):
      y_true=tf.image.resize(y_true,[224,224])
      y_pred=tf.image.resize(y_pred,[224,224])

      perceptual_loss_predicted=fullModel(y_true)
      perceptual_loss_output=fullModel(y_pred)
      mse_loss=tf.keras.losses.MAE(perceptual_loss_output, perceptual_loss_predicted)
      return mse_loss*.1

    def sobel_loss(y_true, y_pred):
        true_label_edges = tf.image.sobel_edges(y_true)
        predicted_label_edges = tf.image.sobel_edges(y_pred)
        edge_loss=tf.keras.losses.MAE(true_label_edges, predicted_label_edges)

        return edge_loss
    def mse_loss(y_true, y_pred):
        mse_loss=tf.keras.losses.MAE(y_true, y_pred)

        return  mse_loss*10

    def mse_loss_2(y_true, y_pred):
        mse_loss=tf.keras.losses.MAE(y_true, y_pred)

        return  mse_loss

    def ssim_loss(y_true, y_pred):

        ssim_loss=-tf.image.ssim(y_pred, y_true, 2 )    
        return multiply_variable(ssim_loss)

    def Residual_block_two_inputs_scale_0 (input_mag,input_frame_b,filters_,kernal_size,name_):
        out_1=tf.keras.layers.concatenate([input_mag,input_frame_b])
        out_2_1=tf.keras.layers.Conv2D(filters=filters_, kernel_size=(3,3),dilation_rate=1,strides=(1, 1),padding="same")(out_1)
        out_2_1=tf.keras.layers.Activation(activation=activaion_function)(out_2_1)
        out_1=tf.keras.layers.concatenate([out_2_1,input_frame_b])
        out_2_1=tf.keras.layers.Conv2D(filters=filters_, kernel_size=(3,3),dilation_rate=1,strides=(1, 1),padding="same")(out_1)
        out_2_1=tf.keras.layers.Activation(activation=activaion_function)(out_2_1) 
        return out_2_1     
    class softmax_weights(tf.keras.layers.Layer):
        def __init__(self, input_dim,name_):
            super(softmax_weights, self).__init__(name=name_+'custum_layer')
            self.w = self.add_weight(shape=(input_dim,), initializer="ones", trainable=True,name=name_+'weights')
            self.input_dim=input_dim
            # self.softmax =layers.softmax()
        @tf.function
        def call(self,input):
            return  self.w 
    class fft_layer(tf.keras.layers.Layer):
        def __init__(self,name_):
            super(fft_layer, self).__init__(name=name_+'custum_layer')
      
        @tf.function
        def call(self,input):
            pi = tf.constant(m.pi)
            features_fft=tf.signal.rfft2d(input)
            features_angle=tf.math.angle(features_fft)/pi
            features_magnitude=tf.math.abs(features_fft)
            return  features_magnitude,features_angle      
    class ifft_layer(tf.keras.layers.Layer):
        def __init__(self,name_):
            super(ifft_layer, self).__init__(name=name_+'custum_layer')
        @tf.function
        def call(self,input_magnitude,input_angle):
            pi = tf.constant(m.pi)
            real=input_magnitude*tf.math.cos(input_angle*pi)
            imag=input_magnitude*tf.math.sin(input_angle*pi)
            feature=tf.dtypes.complex(real,imag)
            return  tf.math.real(tf.signal.irfft2d(feature))     
    kernal=3
    kernal_size=(3,3)

    print("correct model file")

    phase_fa=tf.keras.Input(shape=(image_height,image_width, 2))
    phase_fb=tf.keras.Input(shape=(image_height,image_width, 2))
    magnification_factor_subtract=tf.keras.Input(shape=(1,))


    subtract_two_inputs_subtract_1=tf.keras.layers.subtract([phase_fb,phase_fa])
    subtract_two_inputs_subtract_1=Residual_block_two_inputs_scale_0 (subtract_two_inputs_subtract_1,phase_fb,filters_,kernal_size,'phae_difference_1')

    subtract_two_inputs_subtract_1=tf.keras.layers.Multiply()([subtract_two_inputs_subtract_1,magnification_factor_subtract])
    final_phase_fb=Residual_block_two_inputs_scale_0 (subtract_two_inputs_subtract_1,phase_fb,filters_,kernal_size,'phae_difference_2')
    final_phase_fb=Residual_block_two_inputs_scale_0 (final_phase_fb,phase_fb,filters_,kernal_size,'phae_difference_2_2')
    final_phase_fb=Residual_block_two_inputs_scale_0 (final_phase_fb,phase_fb,filters_,kernal_size,'phae_difference_2_3')
    final_phase_fb=tf.keras.layers.Conv2D(filters=2, kernel_size=(1,1),strides=(1, 1),padding="same")(final_phase_fb)

    final_phase_fb=final_phase_fb+phase_fb
    motion_magnification_subtract = tf.keras.Model(inputs=[phase_fa,phase_fb,magnification_factor_subtract],
                    outputs=[final_phase_fb])

    adam=tf.keras.optimizers.Adam(
        learning_rate=0.0001, beta_1=0.9, beta_2=0.999, epsilon=1e-07, amsgrad=False,
        name='Adam')

    motion_magnification_subtract.compile(loss=['mean_absolute_error','mean_absolute_error'
                                       'mean_absolute_error','mean_absolute_error'
                                       ],
                                 optimizer=adam, metrics=['accuracy'])
    motion_magnification_subtract.summary()

    Amp_fa=tf.keras.Input(shape=(image_height,image_width, 2))
    Amp_fb=tf.keras.Input(shape=(image_height,image_width, 2))
    magnification_factor_subtract_Amp=tf.keras.Input(shape=(1,))


    subtract_two_inputs_subtract_1=tf.keras.layers.subtract([Amp_fb,Amp_fa])
    subtract_two_inputs_subtract_1=Residual_block_two_inputs_scale_0 (subtract_two_inputs_subtract_1,Amp_fb,filters_,kernal_size,'amp_difference_1')

    subtract_two_inputs_subtract_1=tf.keras.layers.Multiply()([subtract_two_inputs_subtract_1,magnification_factor_subtract_Amp])
    final_phase_fb=Residual_block_two_inputs_scale_0 (subtract_two_inputs_subtract_1,Amp_fb,filters_,kernal_size,'amp_difference_2')
    final_phase_fb=Residual_block_two_inputs_scale_0 (final_phase_fb,Amp_fb,filters_,kernal_size,'amp_difference_2_2')
    final_phase_fb=Residual_block_two_inputs_scale_0 (final_phase_fb,Amp_fb,filters_,kernal_size,'amp_difference_2_3')
    final_phase_fb=tf.keras.layers.Conv2D(filters=2, kernel_size=(1,1),strides=(1, 1),padding="same")(final_phase_fb)

    final_phase_fb=final_phase_fb+Amp_fb
    motion_magnification_subtract_Amp = tf.keras.Model(inputs=[Amp_fa,Amp_fb,magnification_factor_subtract_Amp],
                    outputs=[final_phase_fb])

    adam=tf.keras.optimizers.Adam(
        learning_rate=0.0001, beta_1=0.9, beta_2=0.999, epsilon=1e-07, amsgrad=False,
        name='Adam')

    motion_magnification_subtract_Amp.compile(loss=['mean_absolute_error','mean_absolute_error'
                                       'mean_absolute_error','mean_absolute_error'
                                       ],
                                 optimizer=adam, metrics=['accuracy'])
    motion_magnification_subtract_Amp.summary()
    final_Amp_fb=tf.keras.Input(shape=(image_height,image_width, 2))
    final_phase_fb=tf.keras.Input(shape=(image_height,image_width, 2))
    frame_B=tf.keras.Input(shape=(image_height,image_width, 3))
    frame_A=tf.keras.Input(shape=(image_height,image_width, 3))
    magnification_factor_subtract=tf.keras.Input(shape=(1,))

    ifft_o1 = ifft_layer('frame_3_out_1_4_ifft')
    frame_3_out_1_4_ifft=ifft_o1(final_Amp_fb,final_phase_fb)
    phase_mag=tf.keras.layers.Conv2D(filters=3, kernel_size=(1,1),strides=(1, 1),padding="same")(frame_3_out_1_4_ifft)

    phase_mag_diff=phase_mag-frame_A
    attention_difference_=tf.keras.layers.Conv2D(filters=filters_, kernel_size=(3,3),dilation_rate=1,strides=(1, 1),padding="same")(phase_mag_diff)
    attention_difference=tf.keras.layers.Conv2D(filters=1, kernel_size=(3,3),dilation_rate=1,strides=(1, 1),padding="same")(attention_difference_)
    attention_difference=tf.keras.layers.Activation(activation='sigmoid')(attention_difference)

    spatial_difference_=frame_B-frame_A

    spatial_difference_1_=Residual_block_two_inputs_scale_0 (spatial_difference_,spatial_difference_,filters_,kernal_size,'spatial_difference_1')

    spatial_difference_1_=tf.keras.layers.Multiply()([spatial_difference_1_,attention_difference])
    spatial_difference=tf.keras.layers.Multiply()([spatial_difference_1_,magnification_factor_subtract])
    spatial_difference_2_1=Residual_block_two_inputs_scale_0 (spatial_difference,spatial_difference_1_,filters_,kernal_size,'spatial_difference_2_1')
    spatial_difference_2_2=Residual_block_two_inputs_scale_0 (spatial_difference_2_1,spatial_difference,filters_,kernal_size,'spatial_difference_2_2')
    spatial_difference_1=Residual_block_two_inputs_scale_0 (spatial_difference_2_2,spatial_difference_2_1,filters_,kernal_size,'spatial_difference_2_3')

    frame_A_mag_1=tf.keras.layers.Conv2D(filters=filters_, kernel_size=(1,1),strides=(1, 1),padding="same")(frame_A)
    frame_B_mag_1=tf.keras.layers.Conv2D(filters=filters_, kernel_size=(1,1),strides=(1, 1),padding="same")(frame_B)
    phase_mag_1=tf.keras.layers.Conv2D(filters=filters_, kernel_size=(1,1),strides=(1, 1),padding="same")(phase_mag)


    phase_mag_2=tf.keras.layers.AveragePooling2D(pool_size=(4, 4), strides=(2,2), padding='same')(phase_mag_1)
    phase_mag_3=tf.keras.layers.AveragePooling2D(pool_size=(4, 4), strides=(2,2), padding='same')(phase_mag_2)
    phase_mag_4=tf.keras.layers.AveragePooling2D(pool_size=(4, 4), strides=(2,2), padding='same')(phase_mag_3)

    spatial_difference_2=tf.keras.layers.AveragePooling2D(pool_size=(4, 4), strides=(2,2), padding='same')(spatial_difference_1)
    spatial_difference_3=tf.keras.layers.AveragePooling2D(pool_size=(4, 4), strides=(2,2), padding='same')(spatial_difference_2)
    spatial_difference_4=tf.keras.layers.AveragePooling2D(pool_size=(4, 4), strides=(2,2), padding='same')(spatial_difference_3)

    frame_A_mag_2=tf.keras.layers.AveragePooling2D(pool_size=(4, 4), strides=(2,2), padding='same')(frame_A_mag_1)
    frame_A_mag_3=tf.keras.layers.AveragePooling2D(pool_size=(4, 4), strides=(2,2), padding='same')(frame_A_mag_2)
    frame_A_mag_4=tf.keras.layers.AveragePooling2D(pool_size=(4, 4), strides=(2,2), padding='same')(frame_A_mag_3)
    frame_B_mag_2=tf.keras.layers.AveragePooling2D(pool_size=(4, 4), strides=(2,2), padding='same')(frame_B_mag_1)
    frame_B_mag_3=tf.keras.layers.AveragePooling2D(pool_size=(4, 4), strides=(2,2), padding='same')(frame_B_mag_2)
    frame_B_mag_4=tf.keras.layers.AveragePooling2D(pool_size=(4, 4), strides=(2,2), padding='same')(frame_B_mag_3)

    feature_difference=phase_mag_4-frame_A_mag_4+spatial_difference_4
    magnified_frame=Residual_block_two_inputs_scale_0(feature_difference,frame_B_mag_4,filters_,3,'magnified_frame_3')
    magnified_frame=Residual_block_two_inputs_scale_0(magnified_frame,frame_B_mag_4,filters_,3,'magnified_frame_3_2')
    magnified_frame=Residual_block_two_inputs_scale_0(magnified_frame,frame_B_mag_4,filters_,3,'magnified_frame_3_3')
    finaal_frame=magnified_frame+phase_mag_4
    magnified_frame=tf.keras.layers.concatenate([finaal_frame,frame_B_mag_4])

    magnified_frame=tf.keras.layers.Conv2DTranspose(filters=(filters_), kernel_size=(4,4),strides=(2, 2),padding="same")(magnified_frame)

    feature_difference=magnified_frame-frame_A_mag_3+spatial_difference_3

    magnified_frame=Residual_block_two_inputs_scale_0(feature_difference,frame_B_mag_3,filters_,3,'magnified_frame_4')
    magnified_frame=Residual_block_two_inputs_scale_0(magnified_frame,frame_B_mag_3,filters_,3,'magnified_frame_4_2')
    magnified_frame=Residual_block_two_inputs_scale_0(magnified_frame,frame_B_mag_3,filters_,3,'magnified_frame_4_3')
    finaal_frame=magnified_frame+phase_mag_3
    magnified_frame=tf.keras.layers.concatenate([finaal_frame,frame_B_mag_3])

    magnified_frame=tf.keras.layers.Conv2DTranspose(filters=(filters_), kernel_size=(4,4),strides=(2, 2),padding="same")(magnified_frame)

    feature_difference=magnified_frame-frame_A_mag_2+spatial_difference_2
    magnified_frame=Residual_block_two_inputs_scale_0(feature_difference,frame_B_mag_2,filters_,3,'magnified_frame_5_')
    magnified_frame=Residual_block_two_inputs_scale_0(magnified_frame,frame_B_mag_2,filters_,3,'magnified_frame_5_2')
    magnified_frame=Residual_block_two_inputs_scale_0(magnified_frame,frame_B_mag_2,filters_,3,'magnified_frame_5_3')
    finaal_frame=magnified_frame+phase_mag_2

    magnified_frame=tf.keras.layers.concatenate([finaal_frame,frame_B_mag_2])

    magnified_frame=tf.keras.layers.Conv2DTranspose(filters=(filters_), kernel_size=(4,4),strides=(2, 2),padding="same")(magnified_frame)
    feature_difference=magnified_frame-frame_A_mag_1+spatial_difference_1
    magnified_frame=Residual_block_two_inputs_scale_0(feature_difference,frame_B_mag_1,filters_,3,'magnified_frame_6')
    magnified_frame=Residual_block_two_inputs_scale_0(magnified_frame,frame_B_mag_1,filters_,3,'magnified_frame_6_2')
    magnified_frame=Residual_block_two_inputs_scale_0(magnified_frame,frame_B_mag_1,filters_,3,'magnified_frame_6_3')
    finaal_frame=magnified_frame+phase_mag_1


    frame_3_out_1=tf.keras.layers.Conv2D(filters=3, kernel_size=(1,1),strides=(1, 1),padding="same")(magnified_frame)
    frame_3_out_1=tf.keras.layers.Activation(activation='tanh',name='frame_3_out_1')(frame_3_out_1)
    motion_magnification_decoder = tf.keras.Model(inputs=[final_phase_fb,final_Amp_fb,frame_B,frame_A,magnification_factor_subtract],
                    outputs=[frame_3_out_1])

    adam=tf.keras.optimizers.Adam(
        learning_rate=0.0001, beta_1=0.9, beta_2=0.999, epsilon=1e-07, amsgrad=False,
        name='Adam')

    motion_magnification_decoder.compile(loss=['mean_absolute_error','mean_absolute_error'
                                       ,'mean_absolute_error'
                                       ],
                                 optimizer=adam, metrics=['accuracy'])
    motion_magnification_decoder.summary()

    frame_A=tf.keras.Input(shape=(image_height,image_width,3))
    frame_B=tf.keras.Input(shape=(image_height,image_width,3))

    magnification_factor=tf.keras.Input(shape=(1,))

        
    fft_a = fft_layer('frame_A_fft')
    frame_A_fft,frame_A_fft_angle=fft_a(frame_A)
    fft_b = fft_layer('frame_B_fft')
    frame_B_fft,frame_B_fft_angle=fft_b(frame_B)

    final_phase_=motion_magnification_subtract([frame_A_fft_angle,frame_B_fft_angle,magnification_factor])
    final_Amp_=motion_magnification_subtract_Amp([frame_A_fft,frame_B_fft,magnification_factor])


    frame_3_out_1_4=motion_magnification_decoder([final_phase_,final_Amp_,frame_B,frame_A,magnification_factor])
    final_phase_1=tf.keras.layers.Conv2D(filters=2, kernel_size=(3,3),strides=(1, 1),padding="same")(final_phase_)


    motion_magnification = tf.keras.Model(inputs=[frame_A,frame_B,magnification_factor],
                    outputs=[frame_3_out_1_4,frame_3_out_1_4,frame_3_out_1_4,final_phase_1,final_Amp_ ])

    adam=tf.keras.optimizers.Adam(learning_rate=0.0001, beta_1=0.9, beta_2=0.999, epsilon=1e-07, amsgrad=False,name='Adam')

    motion_magnification.compile(loss=[perceptual_loss,sobel_loss,mse_loss,mse_loss_2,mse_loss_2],
                                 optimizer=adam, metrics=['accuracy'])
    motion_magnification.summary()

    img_input_frame_A = np.zeros(( 1,image_height, image_width, 3)).astype('float')
    img_input_frame_B = np.zeros(( 1,image_height, image_width, 3)).astype('float')
    motion_magnification.load_weights(weights_path) 
    for i in range(no_of_frames):                           
        train_imgA = ((cv2.imread(file_path+str(i)+'.jpg')))
        train_imgA =  cv2.resize(train_imgA, (image_height, image_width))
        train_imgA=(train_imgA/127.5)-1
        train_imgB = ((cv2.imread(file_path+'/'+str(i+gap)+'.jpg')))
        train_imgB =  cv2.resize(train_imgB, (image_height, image_width))  
        train_imgB=((train_imgB/127.5)-1)
        img_input_frame_A[0,:,:,0:3]=train_imgA
        img_input_frame_B[0,:,:,0:3]=train_imgB
        m_f_2 = np.array([m_f])
        hst_predict=((motion_magnification.predict([img_input_frame_A,img_input_frame_B,m_f_2])[0]+1)*127)
        hst_predict=np.squeeze(hst_predict)  
        filename = output_path+str(i)+'.jpg'
        cv2.imwrite(filename, hst_predict) 
    return print('done')

input_frame_path='./input_frames/' 
output_path_frames='./output_frames/'
input_videos_path='./balloon.avi'
output_video='./output_videos/balloon_magnified.avi'

magnification_factor=10
weights_path='./motion_magnification_D2_model.h5'

frame_difference=1
no_of_frames,size=FrameCapture(input_videos_path,input_frame_path)
input_image_size=720#size[0]

magnification(no_of_frames-frame_difference,input_frame_path,frame_difference,magnification_factor,output_path_frames,(input_image_size,input_image_size),weights_path)
frame_to_video((size[1],size[0]),no_of_frames-frame_difference,output_path_frames,output_video,'MJPG')
